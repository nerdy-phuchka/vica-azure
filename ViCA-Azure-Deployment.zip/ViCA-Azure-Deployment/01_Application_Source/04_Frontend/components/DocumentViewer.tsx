'use client';
import {useEffect,useRef,useState} from 'react';
type Box={polygon?:number[],content?:string};
export default function DocumentViewer({blob,mime,pageNumber,lines,width,height,quote}:{blob:Blob|null,mime:string,pageNumber:number,lines:Box[],width?:number,height?:number,quote?:string}) {
  const canvas=useRef<HTMLCanvasElement>(null);
  const [error,setError]=useState('');
  const [url,setUrl]=useState('');
  useEffect(()=>{if(!blob)return;const u=URL.createObjectURL(blob);setUrl(u);return()=>URL.revokeObjectURL(u);},[blob]);
  useEffect(()=>{
    let cancelled=false;let task:any;let renderTask:any;
    async function render() {
      if(!blob||mime!=='application/pdf'||!canvas.current)return;
      try {
        const pdfjs=await import('pdfjs-dist');
        pdfjs.GlobalWorkerOptions.workerSrc=new URL('pdfjs-dist/build/pdf.worker.min.mjs',import.meta.url).toString();
        task=pdfjs.getDocument({data:new Uint8Array(await blob.arrayBuffer()),isEvalSupported:false});
        const pdf=await task.promise;
        const page=await pdf.getPage(Math.min(pageNumber,pdf.numPages));
        if(cancelled)return;
        const viewport=page.getViewport({scale:1.2});
        const target=canvas.current!;target.width=viewport.width;target.height=viewport.height;
        const context=target.getContext('2d')!;
        renderTask=page.render({canvasContext:context,canvas:target,viewport});await renderTask.promise;
        if(quote&&width&&height) {
          context.fillStyle='rgba(255,190,50,0.35)';
          for(const line of lines)if(line.polygon&&line.content&&(quote.includes(line.content)||line.content.includes(quote))) {
            const xs=line.polygon.filter((_,i)=>i%2===0).map(x=>x/width*viewport.width);
            const ys=line.polygon.filter((_,i)=>i%2===1).map(y=>y/height*viewport.height);
            context.fillRect(Math.min(...xs),Math.min(...ys),Math.max(...xs)-Math.min(...xs),Math.max(...ys)-Math.min(...ys));
          }
        }
        setError('');
      }catch(e){if(!cancelled)setError('PDF preview unavailable. Download the original or inspect the extracted text.');}
    }
    render();return()=>{cancelled=true;renderTask?.cancel();task?.destroy();};
  },[blob,mime,pageNumber,lines,width,height,quote]);
  if(!blob)return <div className="empty">Select a document to inspect its source.</div>;
  return <div className="document-viewer">{error&&<p className="warning">{error}</p>}
    {mime==='application/pdf'?<canvas ref={canvas}/>:mime.startsWith('image/')?<img src={url} alt="Original borrower document"/>:<p>Original available for download. Extracted content appears below.</p>}
    <a className="button secondary" href={url} download="source-document">Download original</a>
  </div>;
}
