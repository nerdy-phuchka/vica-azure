  // Cockpit configuration is a local preview template, separate from lending policy.
  const sectionNames={overview:'Borrower 360',documents:'Documents & evidence',financials:'Financial spreading',risk:'Risk & stress',memo:'Credit Assessment Memo',decision:'Committee decision'};
  const sectionDescriptions={overview:'Profile fields, summary metrics and assessment checkpoints',documents:'Document requirements, freshness limits and accepted languages',financials:'Reporting periods, display units and financial metrics',risk:'Stress assumptions, slider limits and the risk register',memo:'Included chapters, chapter titles and presentation order',decision:'Review roles, referral limits, clearances and conditions'};
  let sectionDefaults,configOpen=null;
  function initSectionConfiguration(){
    sectionDefaults={
      overview:{metrics:{revenue:true,dscr:true,leverage:true,vintage:true},fields:{sector:true,location:true,ownership:true,group:true,concentration:true},checkpoint:'Verify ultimate beneficial ownership and all connected exposures.'},
      documents:{english:true,arabic:true,documents:defaultDocs.map(d=>({name:d.name,required:d.required,age:d.age}))},
      financials:{years:3,unit:'millions',metrics:{revenue:true,ebitda:true,cash:true,service:true,dscr:true,current:true,debt:true,equity:true,leverage:false}},
      risk:{cashDefault:0,cashMax:50,serviceDefault:0,serviceMax:40,risks:{cash:true,concentration:true,data:true,security:true,external:true},customRisk:'',customMitigant:''},
      memo:{sections:memoFactory(b()).map((s,i)=>({key:'chapter-'+i,title:s.title,included:true}))},
      decision:{limit:10000000,preparer:'Relationship manager',reviewer:'Independent credit reviewer',approver:'Credit Committee',clearances:{compliance:true,legal:true,bureau:true,valuation:false},conditions:'Complete independent credit review.\nResolve all policy exceptions with the authorised authority.\nVerify security and pre-disbursement conditions.'}
    };
    const retained=state.sectionSettings;
    state.sectionSettings={schema:1,applied:clone(sectionDefaults),drafts:{},versions:{},history:[]};
    if(retained&&retained.schema===1){
      Object.keys(sectionNames).forEach(key=>{if(retained.applied?.[key])state.sectionSettings.applied[key]=retained.applied[key];});
      state.sectionSettings.drafts=retained.drafts||{};state.sectionSettings.versions=retained.versions||{};state.sectionSettings.history=retained.history||[];
    }
    const tabs=$('.vc-cockpit-tabs');
    tabs.insertAdjacentHTML('afterend','<div id="vc-section-tools" class="vc-section-tools"><div><strong id="vc-section-label"></strong><small id="vc-section-summary"></small></div><div class="vc-actions"><span class="vc-badge" id="vc-section-version">Template v1</span><button type="button" class="vc-link cursor-interaction" id="vc-configure-section">Configure →</button></div></div><section id="vc-section-settings" class="vc-panel vc-settings" aria-labelledby="vc-config-title" hidden></section>');
    $('#vc-configure-section').addEventListener('click',()=>configOpen?closeSectionConfiguration():openSectionConfiguration(state.cockpit));
    $('[data-cockpit-panel="risk"] [data-nav="policy"]').textContent='Policy rules →';
    const policyTabs=$('[data-policy-tab]')?.parentElement;
    if(policyTabs){
      policyTabs.insertAdjacentHTML('beforeend','<button type="button" class="cursor-interaction" data-policy-tab="sections" aria-selected="false">Cockpit sections</button>');
      $('[data-screen="policy"]').insertAdjacentHTML('beforeend','<div data-policy-panel="sections" hidden><section class="vc-panel" style="margin-top:16px"><div class="vc-panel-head"><div><h2>Cockpit section configuration</h2><p>SME portfolio templates · local preview</p></div></div><div id="vc-section-directory"></div></section></div>');
    }
    root.addEventListener('click',event=>{
      const button=event.target.closest('button');if(!button)return;
      if(button.dataset.configureSection){showScreen('cockpit');setCockpit(button.dataset.configureSection);openSectionConfiguration(button.dataset.configureSection);}
      if(button.dataset.cfgAction==='close')closeSectionConfiguration();
      if(button.dataset.cfgAction==='save')saveSectionConfiguration(false);
      if(button.dataset.cfgAction==='apply')saveSectionConfiguration(true);
      if(button.dataset.cfgMove){
        collectSectionConfiguration();const items=state.sectionSettings.drafts.memo.sections,index=Number(button.dataset.cfgIndex),other=index+Number(button.dataset.cfgMove);
        if(other<0||other>=items.length)return;[items[index],items[other]]=[items[other],items[index]];renderSectionConfiguration();
        $('#vc-section-settings').querySelector('[data-cfg-index="'+other+'"][data-cfg-move="'+button.dataset.cfgMove+'"]')?.focus();
      }
    });
    $('#vc-section-settings').addEventListener('input',()=>{$('#vc-config-status').textContent='Unsaved configuration draft';});
    $('#vc-section-settings').addEventListener('submit',event=>event.preventDefault());
    updateSectionDirectory();syncSectionToolbar();
    $('#vc-cash-cut').value=cfg('risk').cashDefault;$('#vc-service-rise').value=cfg('risk').serviceDefault;
  }
  function cfg(section){return state.sectionSettings?.applied[section]||sectionDefaults[section];}
  function syncSectionToolbar(){
    if(!$('#vc-section-label'))return;
    $('#vc-section-label').textContent=sectionNames[state.cockpit];$('#vc-section-summary').textContent=sectionDescriptions[state.cockpit];
    $('#vc-section-version').textContent='Template v'+(state.sectionSettings.versions[state.cockpit]||1);
    $('#vc-configure-section').textContent=configOpen?'Back to section ←':'Configure →';
    $('#vc-configure-section').setAttribute('aria-label',configOpen?'Back to '+sectionNames[state.cockpit]:'Configure '+sectionNames[state.cockpit]);
    $('#vc-configure-section').setAttribute('aria-expanded',String(!!configOpen));$('#vc-configure-section').setAttribute('aria-controls','vc-section-settings');
  }
  function updateSectionDirectory(){
    if(!$('#vc-section-directory'))return;
    $('#vc-section-directory').innerHTML=Object.keys(sectionNames).map(key=>'<div class="vc-row"><div><strong>'+sectionNames[key]+'</strong><small>'+sectionDescriptions[key]+' · v'+(state.sectionSettings.versions[key]||1)+'</small></div><button type="button" class="vc-link cursor-interaction" data-configure-section="'+key+'">Configure →</button></div>').join('');
  }
  function openSectionConfiguration(section){
    if(configOpen)collectSectionConfiguration();
    configOpen=section;state.sectionSettings.drafts[section]??=clone(cfg(section));
    $$('[data-cockpit-panel]').forEach(panel=>panel.hidden=true);$('#vc-section-settings').hidden=false;renderSectionConfiguration();syncSectionToolbar();
  }
  function closeSectionConfiguration(){
    if(configOpen)collectSectionConfiguration();configOpen=null;$('#vc-section-settings').hidden=true;
    $$('[data-cockpit-panel]').forEach(panel=>panel.hidden=panel.dataset.cockpitPanel!==state.cockpit);syncSectionToolbar();
  }
  function configField(label,path,value,type='text',options=''){
    const input=type==='textarea'?'<textarea data-cfg-path="'+path+'" maxlength="3000">'+esc(value)+'</textarea>':'<input data-cfg-path="'+path+'" type="'+type+'" value="'+esc(value)+'" '+options+'>';
    return '<label>'+esc(label)+input+'</label>';
  }
  function configCheck(label,path,value){return '<label class="vc-check-label"><input type="checkbox" data-cfg-path="'+path+'"'+(value?' checked':'')+'>'+esc(label)+'</label>';}
  function configChecks(heading,items,prefix,values){return '<fieldset><legend>'+esc(heading)+'</legend>'+items.map(([key,label])=>configCheck(label,prefix+'.'+key,values[key])).join('')+'</fieldset>';}
  function configSelect(label,path,value,choices){return '<label>'+esc(label)+'<select data-cfg-path="'+path+'">'+choices.map(([v,t])=>'<option value="'+esc(v)+'"'+(String(value)===String(v)?' selected':'')+'>'+esc(t)+'</option>').join('')+'</select></label>';}
  function renderSectionConfiguration(){
    const key=configOpen,d=state.sectionSettings.drafts[key];let body='';
    if(key==='overview')body='<div class="vc-config-grid">'+configChecks('Summary metrics',[['revenue','Annual revenue'],['dscr','Cash-flow DSCR'],['leverage','Debt / equity'],['vintage','Business vintage']],'metrics',d.metrics)+configChecks('Profile fields',[['sector','Sector'],['location','Operating location'],['ownership','Ownership'],['group','Group exposure'],['concentration','Customer concentration']],'fields',d.fields)+'</div>'+configField('Additional assessment checkpoint','checkpoint',d.checkpoint,'textarea');
    if(key==='documents')body='<fieldset><legend>Accepted document languages</legend><div class="vc-actions">'+configCheck('English','english',d.english)+configCheck('Arabic','arabic',d.arabic)+'</div></fieldset><div class="vc-config-docs">'+d.documents.map((doc,i)=>'<div class="vc-config-doc">'+configCheck(doc.name,'documents.'+i+'.required',doc.required)+configField('Maximum age (months)','documents.'+i+'.age',doc.age,'number','min="1" max="120" step="1" required')+'</div>').join('')+'</div><small>Checked documents are required. Freshness limits describe the template requirement; authenticity and actual document dates still require validation.</small>';
    if(key==='financials')body='<div class="vc-config-grid">'+configSelect('Historical reporting periods','years',d.years,[[1,'Latest year'],[2,'Latest two years'],[3,'Latest three years']])+configSelect('Display units (SAR)','unit',d.unit,[['millions','SAR millions'],['thousands','SAR thousands'],['actual','SAR actuals']])+'</div>'+configChecks('Financial spread rows',[['revenue','Revenue'],['ebitda','EBITDA'],['cash','Cash available for debt service'],['service','Annual debt service'],['dscr','Cash-flow DSCR'],['current','Current ratio'],['debt','Funded debt'],['equity','Equity'],['leverage','Debt / equity']],'metrics',d.metrics)+'<div class="vc-info">Cash-flow DSCR = reviewed cash available ÷ total annual debt service. Display settings preserve the underlying calculation and source figures.</div>';
    if(key==='risk')body='<div class="vc-config-grid">'+configField('Default cash-flow reduction (%)','cashDefault',d.cashDefault,'number','min="0" max="90" step="1" required')+configField('Maximum cash-flow reduction (%)','cashMax',d.cashMax,'number','min="1" max="90" step="1" required')+configField('Default debt-service increase (%)','serviceDefault',d.serviceDefault,'number','min="0" max="200" step="1" required')+configField('Maximum debt-service increase (%)','serviceMax',d.serviceMax,'number','min="1" max="200" step="1" required')+'</div>'+configChecks('Risk register topics',[['cash','Cash-flow resilience'],['concentration','Customer concentration'],['data','Data reliability'],['security','Security and legal'],['external','External risk']],'risks',d.risks)+'<div class="vc-config-grid">'+configField('Additional risk (optional)','customRisk',d.customRisk)+configField('Required mitigant','customMitigant',d.customMitigant,'textarea')+'</div><div class="vc-info">DSCR thresholds and policy rules are configured under Policy Configuration. These settings control scenario assumptions.</div>';
    if(key==='memo')body='<small>Include chapters, edit their titles and use the arrows to change their order. Existing analyst text and excluded chapters are retained in the dossier.</small><div class="vc-config-chapters">'+d.sections.map((s,i)=>'<div class="vc-config-chapter"><label class="vc-check-label"><input type="checkbox" data-cfg-path="sections.'+i+'.included"'+(s.included?' checked':'')+'><span>'+String(i+1).padStart(2,'0')+'</span></label><label class="vc-config-chapter-title"><span class="vc-sr-only">Chapter '+(i+1)+' title</span><input data-cfg-path="sections.'+i+'.title" value="'+esc(s.title)+'" maxlength="140" required></label><div class="vc-actions"><button type="button" class="cursor-interaction" data-cfg-move="-1" data-cfg-index="'+i+'" aria-label="Move chapter '+(i+1)+' up"'+(i===0?' disabled':'')+'>↑</button><button type="button" class="cursor-interaction" data-cfg-move="1" data-cfg-index="'+i+'" aria-label="Move chapter '+(i+1)+' down"'+(i===d.sections.length-1?' disabled':'')+'>↓</button></div></div>').join('')+'</div>';
    if(key==='decision')body='<div class="vc-config-grid">'+configField('Committee referral above (SAR)','limit',d.limit,'number','min="0" max="1000000000" step="1" required')+configField('Preparing officer role','preparer',d.preparer,'text','maxlength="100" required')+configField('Independent reviewer role','reviewer',d.reviewer,'text','maxlength="100" required')+configField('Final decision authority','approver',d.approver,'text','maxlength="100" required')+'</div>'+configChecks('Required specialist clearances',[['compliance','Compliance / sanctions / KYC'],['legal','Legal and security documentation'],['bureau','Credit bureau confirmation'],['valuation','Independent valuation']],'clearances',d.clearances)+configField('Required conditions (one per line)','conditions',d.conditions,'textarea')+'<div class="vc-info">Separate preparation, independent review and authorised approval remain required. Applying this template only changes the preview workflow.</div>';
    const version=state.sectionSettings.versions[key]||1;
    $('#vc-section-settings').innerHTML='<div class="vc-panel-head"><div><div class="vc-overline">SME portfolio template</div><h2 id="vc-config-title">Configure '+sectionNames[key]+'</h2><p>'+sectionDescriptions[key]+'</p></div><span class="vc-badge blue">Preview settings · v'+version+'</span></div><form id="vc-config-form">'+body+'</form><div class="vc-config-footer"><small id="vc-config-status" role="status">Draft settings · apply to see changes in the preview</small><div id="vc-config-error" class="vc-warning" role="alert" hidden></div><div class="vc-actions"><button type="button" class="cursor-interaction" data-cfg-action="close">Back to section</button><button type="button" class="cursor-interaction" data-cfg-action="save">Save configuration draft</button><button type="button" class="vc-lime cursor-interaction" data-cfg-action="apply">Apply to preview</button></div><small>Saved in this browser where storage is available. Real policy activation and workflow changes require the connected application and authorised review.</small></div>';
  }
  function collectSectionConfiguration(){
    if(!configOpen)return;
    const draft=state.sectionSettings.drafts[configOpen];
    $$('#vc-config-form [data-cfg-path]').forEach(input=>{const parts=input.dataset.cfgPath.split('.');let target=draft;for(let i=0;i<parts.length-1;i++)target=target[parts[i]];target[parts[parts.length-1]]=input.type==='checkbox'?input.checked:input.type==='number'||input.dataset.cfgPath==='years'?Number(input.value):input.value;});
    return draft;
  }
  function configurationError(section,d){
    if(section==='overview'&&!Object.values(d.metrics).some(Boolean))return 'Select at least one summary metric.';
    if(section==='documents'&&!d.english&&!d.arabic)return 'Accept at least one document language.';
    if(section==='financials'&&!Object.values(d.metrics).some(Boolean))return 'Select at least one financial metric.';
    if(section==='risk'){
      if(d.cashDefault>d.cashMax||d.serviceDefault>d.serviceMax)return 'A default stress assumption must not exceed its maximum.';
      if(!!d.customRisk.trim()!==!!d.customMitigant.trim())return 'Enter both the additional risk and its mitigant.';
    }
    if(section==='memo'&&!d.sections.some(s=>s.included))return 'Include at least one memo chapter.';
    if(section==='decision'&&new Set([d.preparer,d.reviewer,d.approver].map(s=>s.trim().toLowerCase())).size!==3)return 'Use distinct preparing officer, reviewer and final authority roles.';
    return '';
  }
  function saveSectionConfiguration(apply){
    const section=configOpen,d=collectSectionConfiguration();if(!$('#vc-config-form').reportValidity())return;
    const error=configurationError(section,d);$('#vc-config-error').hidden=!error;$('#vc-config-error').textContent=error;if(error)return;
    if(apply){
      state.sectionSettings.applied[section]=clone(d);state.sectionSettings.versions[section]=(state.sectionSettings.versions[section]||1)+1;
      state.sectionSettings.history.push({section,version:state.sectionSettings.versions[section],at:new Date().toISOString(),action:'Applied to local preview'});
      if(section==='memo')updateExistingMemoTemplates();
      if(section==='risk'){$('#vc-cash-cut').max=d.cashMax;$('#vc-service-rise').max=d.serviceMax;$('#vc-cash-cut').value=d.cashDefault;$('#vc-service-rise').value=d.serviceDefault;}
    }
    const saved=persist();
    if(apply){closeSectionConfiguration();renderBorrower();updateSectionDirectory();}
    else $('#vc-config-status').textContent=saved?'Configuration draft saved in this browser':'Draft retained for this session; browser storage unavailable';
    toast(sectionNames[section]+(apply?' settings applied to the preview.':' configuration draft saved.')+(saved?'':' Browser storage is unavailable; changes last for this session.'));
  }
  function configuredMemoSections(x){
    const original=memoFactory(x).map((section,i)=>({...section,key:'chapter-'+i})),settings=cfg('memo');
    return settings.sections.filter(s=>s.included).map(s=>({...original.find(v=>v.key===s.key),title:s.title}));
  }
  function updateExistingMemoTemplates(){
    Object.entries(state.memos).forEach(([id,memo])=>{
      const borrower=borrowers.find(x=>x.id===id);if(!borrower)return;
      const original=memoFactory(borrower).map((s,i)=>({...s,key:'chapter-'+i}));
      const archived=memo.sectionArchive||{};
      memo.sections.forEach((s,i)=>{const key=s.key||original.find(v=>v.title===s.title)?.key||'chapter-'+i;archived[key]={...s,key};});
      memo.history.push({version:memo.version,title:'Memo preserved before template change',detail:'Text and excluded chapters retained.',sections:clone(memo.sections)});
      memo.sections=cfg('memo').sections.filter(s=>s.included).map(s=>({...clone(archived[s.key]||original.find(v=>v.key===s.key)),key:s.key,title:s.title}));
      memo.sectionArchive=archived;memo.version++;memo.status='Template updated — review draft';memo.dirty=true;
    });state.memoSection=0;
  }
  function applySectionViews(){
    if(!state.sectionSettings)return;
    const x=b(),overview=cfg('overview');
    const kpis={revenue:stat('Annual revenue',money(x.revenue),'FY 2025 · sample'),dscr:stat('Cash-flow DSCR',(x.cash/x.service).toFixed(2)+'x','Cash available / annual service'),leverage:stat('Debt / equity',(x.debt/x.equity).toFixed(2)+'x','Reviewed demonstration figures'),vintage:stat('Business vintage',x.vintage+' years','Independent registry check pending')};
    $('#vc-borrower-kpis').innerHTML=Object.keys(kpis).filter(key=>overview.metrics[key]).map(key=>kpis[key]).join('');
    const fields={sector:['Sector',x.sector],location:['Operating location',x.city],ownership:['Ownership','Two individual sponsors · sample'],group:['Group exposure','Connected-party verification pending'],concentration:['Concentration',x.customers]};
    $('#vc-business-profile').innerHTML=Object.keys(fields).filter(key=>overview.fields[key]).map(key=>row(...fields[key])).join('');
    if(overview.checkpoint.trim())$('#vc-borrower-readiness').insertAdjacentHTML('beforeend','<div class="vc-row"><span>'+esc(overview.checkpoint)+'</span>'+badge('To verify','warn')+'</div>');
    renderConfiguredEvidence();renderConfiguredSpread();
    const risk=cfg('risk');$('#vc-cash-cut').max=risk.cashMax;$('#vc-service-rise').max=risk.serviceMax;$('#vc-cash-cut').step='1';$('#vc-service-rise').step='1';
    const risks={cash:['Cash-flow resilience','Demonstrate repayment under delayed collections and margin pressure.'],concentration:['Customer concentration',x.customers+'. Obtain contract and receivables ageing evidence.'],data:['Data reliability','Reconcile financial statements, banking turnover and tax/commercial evidence.'],security:['Security and legal','Confirm '+x.security.toLowerCase()+'.'],external:['External risk','Complete authorised bureau, sanctions, ownership and adverse-information reviews.']};
    const included=Object.keys(risks).filter(key=>risk.risks[key]).map(key=>risks[key]);if(risk.customRisk.trim())included.push([risk.customRisk,risk.customMitigant]);
    $('#vc-risk-register').innerHTML=included.map(([name,mitigant])=>'<div class="vc-row"><strong>'+esc(name)+'</strong><span>'+esc(mitigant)+'</span></div>').join('');renderStress();renderConfiguredDecision();syncSectionToolbar();
  }
  function renderConfiguredEvidence(){
    const d=cfg('documents'),list=sources(b()),languages=[d.english?'English':null,d.arabic?'Arabic':null].filter(Boolean).join(' / ');
    $('#vc-evidence-list').innerHTML='<div class="vc-info">Accepted languages: '+languages+' · '+d.documents.filter(doc=>doc.required).length+' required document categories</div>'+list.map((s,i)=>{const requirement=d.documents[i];return '<div class="vc-document"><div><strong>'+esc(s.title)+'</strong><small>'+s.id+' · '+(requirement.required?'Required':'Optional')+' · maximum age '+requirement.age+' months</small></div><div class="vc-actions">'+badge(s.status,s.kind)+'<button type="button" class="vc-link cursor-interaction" data-source="'+s.id+'">View</button></div></div>';}).join('');
  }
  function renderConfiguredSpread(){
    const x=b(),d=cfg('financials'),factor=d.unit==='millions'?1e6:d.unit==='thousands'?1000:1,amount=v=>(v/factor).toLocaleString('en-US',{minimumFractionDigits:d.unit==='actual'?0:2,maximumFractionDigits:d.unit==='actual'?0:2});
    const all=[['revenue','Revenue',[x.revenue*.773,x.revenue*.893,x.revenue],'Growth in synthetic series'],['ebitda','EBITDA',[x.ebitda*.68,x.ebitda*.84,x.ebitda],'Operating earnings indicator'],['cash','Cash available for debt service',[x.cash*.69,x.cash*.864,x.cash],'Annual reviewed forecast'],['service','Total annual debt service',[x.service*.8,x.service*.9,x.service],'Existing + proposed obligations'],['dscr','Cash-flow DSCR',[x.cash*.69/(x.service*.8),x.cash*.864/(x.service*.9),x.cash/x.service],'Cash available / annual debt service',true],['current','Current ratio',[1.48,1.61,x.current],'Latest illustrative liquidity',true],['debt','Funded debt',[x.debt*.81,x.debt*.9,x.debt],'Bureau reconciliation pending'],['equity','Equity',[x.equity*.79,x.equity*.9,x.equity],'Quality of equity to be verified'],['leverage','Debt / equity',[x.debt*.81/(x.equity*.79),x.debt*.9/(x.equity*.9),x.debt/x.equity],'Funded debt / equity',true]];
    const years=[2023,2024,2025].slice(-d.years),panel=$('[data-cockpit-panel="financials"]');
    panel.querySelector('thead tr').innerHTML='<th>Metric</th>'+years.map(year=>'<th>FY '+year+'</th>').join('')+'<th>Assessment</th>';
    panel.querySelector('.vc-panel-head p').textContent='Amounts in SAR '+(d.unit==='actual'?'actuals':d.unit)+' · demonstration figures';
    panel.querySelector('.vc-panel-head .vc-badge').textContent='FY '+years.join(' / ');
    $('#vc-spread-rows').innerHTML=all.filter(([key])=>d.metrics[key]).map(([,label,values,comment,ratio])=>'<tr><td>'+label+'</td>'+values.slice(-d.years).map(value=>'<td>'+(ratio?value.toFixed(2)+'x':amount(value))+'</td>').join('')+'<td>'+comment+'</td></tr>').join('');
  }
  function renderConfiguredDecision(){
    const d=cfg('decision'),panel=$('[data-cockpit-panel="decision"]'),limitRoute=b().amount>d.limit?d.approver:'Delegated authority verification';
    if(!$('#vc-configured-decision'))$('#vc-decision-memo').parentElement.insertAdjacentHTML('afterend','<div id="vc-configured-decision"></div>');
    $$('#vc-configured-decision ~ .vc-row').slice(0,3).forEach(el=>el.hidden=true);
    const clearances={compliance:'Compliance / sanctions / KYC',legal:'Legal and security documentation',bureau:'Credit bureau confirmation',valuation:'Independent valuation'};
    $('#vc-configured-decision').innerHTML=row('Preparing officer',d.preparer)+row('Independent reviewer',d.reviewer)+row('Final decision authority',d.approver)+row('Committee referral threshold',money(d.limit))+row('Current case route',limitRoute)+Object.keys(clearances).filter(key=>d.clearances[key]).map(key=>'<div class="vc-row"><span>'+clearances[key]+'</span>'+badge('Pending confirmation','warn')+'</div>').join('')+'<h3 style="margin-top:18px">Required decision conditions</h3><ul>'+d.conditions.split('\n').map(s=>s.trim()).filter(Boolean).map(s=>'<li>'+esc(s)+'</li>').join('')+'</ul>';
    const terms=$$('#vc-borrower-terms .vc-term');if(terms.length)terms[terms.length-1].querySelector('strong').textContent=limitRoute;
  }
