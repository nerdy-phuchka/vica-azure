function memoFactory(x){
  const m=value=>(value/1e6).toFixed(2),base=x.cash/x.service,down=base*.8,combined=base*.8/1.1;
  const quantitativeReferral=x.risk==='exception'||base<1.25;
  const section=(title,text,sources)=>({title,text:text.trim(),sources});
  return [
    section('Executive summary',`
${x.name} (${x.id}) requests ${money(x.amount)} under a ${x.facility.toLowerCase()} for ${x.tenor}. The stated purpose is to ${x.purpose.charAt(0).toLowerCase()+x.purpose.slice(1)}. This memorandum is an AI-authored demonstration using synthetic borrower information. It is a draft for analyst challenge and independent credit review, rather than evidence of a completed bank assessment.

The latest demonstration figures show annual revenue of SAR ${m(x.revenue)} million, EBITDA of SAR ${m(x.ebitda)} million and annual cash available for debt service of SAR ${m(x.cash)} million. Existing and proposed annual debt service totals SAR ${m(x.service)} million, producing base cash-flow DSCR of ${base.toFixed(2)}×. Reducing available cash by 20% produces DSCR of ${down.toFixed(2)}×. These calculations require confirmation that the cash-flow and obligation schedules cover the same period and include all relevant liabilities.

${quantitativeReferral?'The case requires an exception or restructuring assessment under the demonstration rules. A positive recommendation should not proceed without a documented response to the quantitative shortfall.':'The base quantitative profile supports further credit consideration, subject to validating source information, confirming funding need and clearing all legal, compliance and authority requirements.'} No approved internal rating, external bureau result, sanctions clearance or enforceable security opinion has been supplied. These remain explicit pre-decision gaps.`, 'S1, S3, S5, S6'),

    section('Legal identity & incorporation',`
The applicant is recorded in the synthetic registration pack as ${x.name}, with Arabic name ${x.arabic} and demonstration registration reference ${x.cr}. The stated operating location is ${x.city}, Saudi Arabia. The profile records ${x.vintage} years of operating history. These identifiers are retained as source facts in the example and have not been independently corroborated against an official registry.

The reviewer should reconcile legal name, registration number, legal form, incorporation date, licensed activities and expiry dates across the registration, constitutional records, financing request and banking evidence. A translation or transliteration match alone is insufficient to establish that two documents belong to the same legal person. Any Hijri dates should retain their original form and have a reviewed Gregorian conversion before expiry or vintage rules are evaluated.

Outstanding actions include confirming that the applicant can enter the proposed facility, that the licensed activities encompass the financed business, and that no constitutional restriction limits borrowing or granting security. An unresolved entity or authority mismatch should place the case on hold for legal review.`, 'S1, S2'),

    section('Ownership, management & connected group',`
The demonstration ownership schedule identifies two individual sponsors. Their identities, ownership percentages, ultimate control and relationship to the authorised signatories require corroboration. The analyst must trace any intermediate entity rather than stop at the first corporate shareholder. Any beneficial-ownership threshold is to be taken from the applicable approved due-diligence requirements; none is inferred in this example.

Management capability should be assessed through relevant operating experience, financial oversight, continuity arrangements and the quality of reporting. Interviews and site findings should distinguish information provided by management from independently observed facts. Key-person dependence, succession gaps and unusual changes in control should be documented as specific risks with owners and closure actions.

The bank must establish the connected group and aggregate relevant funded and non-funded commitments, guarantees and related-party exposures. The synthetic pack does not establish a complete group structure or prove that all obligations are disclosed. Sponsor support should therefore be treated as contingent until willingness, legal commitment and financial capacity are separately assessed.`, 'S2, S6'),

    section('Business model & operating assessment',`
The borrower operates in ${x.sector.toLowerCase()} and is located in ${x.city}. Its financing request is consistent with the described ${x.facility.toLowerCase()} use case, but consistency of description is only an initial assessment. The reviewer should establish the actual route from customer order through delivery, invoicing, collection and supplier payment, and map the stages that create a funding requirement.

The commercial review should identify revenue streams, contract duration, pricing arrangements, cost drivers, operational dependencies and the resilience of customer demand. ${x.customers}. This concentration should be supported by actual sales or receipt schedules and assessed for common ownership, connected counterparties and expiry or termination risks.

No external market study, verified site inspection or independent customer confirmation is included in the preview. The analyst should request current contracts, delivery evidence, customer and supplier ageing, and a management explanation of seasonality. Any inference about market leadership, sustainable growth or customer quality must remain an assumption until it is supported by evidence.`, 'S1, S3, S6'),

    section('Facility request, purpose & funding need',`
The proposed request is ${money(x.amount)} for ${x.tenor}, described as a ${x.facility.toLowerCase()}. The stated purpose is: ${x.purpose}. The requested amount is an applicant proposal; it is not automatically the supportable credit limit.

Facility sizing should be based on a documented working-capital gap or investment requirement after considering existing lines, supplier credit, customer advances, internal cash and the borrower's contribution. For working-capital exposure, the analysis should connect eligible receivables, inventory, payables and the operating cycle. For term finance, it should verify supplier quotations, asset purpose, contribution, implementation dates and the cash flows expected to service the facility.

The analyst must distinguish fresh money, renewal, enhancement and refinancing. Existing obligations that will be repaid from proceeds should be reconciled to avoid counting both the old and replacement debt as ongoing service. Conversely, a proposed repayment should not be assumed to occur without a controlled settlement mechanism. Final amount, utilisation rules, repayment dates and any clean-down requirements remain subject to approved product policy and independent review.`, 'S5, S6'),

    section('Document quality & reconciliation',`
The example evidence register contains registration information, ownership records, a three-period financial spread, a bank schedule, a cash-flow forecast and supporting debt/commercial schedules. The references identify synthetic evidence categories. They do not establish that original borrower documents have been received or verified in a live environment.

For a real assessment, confirm that each source belongs to the applicant, covers the appropriate period, is complete and is legible. OCR outputs and AI classifications are preliminary. Material values should be reviewed against the original page, including currency, scale, signs, date convention and the treatment of thousands or millions. Corrections should retain the original extraction and a rationale.

Reconciliation should bridge reported revenue to operating bank receipts, explain differences due to credit sales and timing, and separate financing proceeds, owner injections and internal transfers. Financial liabilities must be compared with bureau and banking evidence. Unexplained differences should become assigned clarification tasks. A document that has been read accurately can still be incomplete, unreliable or inconsistent with other evidence.`, 'S1–S6'),

    section('Historical financial performance',`
FY 2025 synthetic revenue is SAR ${m(x.revenue)} million, compared with illustrative prior-year revenue of SAR ${m(x.revenue*.893)} million. EBITDA is SAR ${m(x.ebitda)} million. The earnings profile should be assessed for recurring operating contribution, one-off income, related-party transactions, exceptional expenses and changes in accounting treatment before it is used to support a credit view.

The demonstration spread shows a current ratio of ${x.current.toFixed(2)}× and funded debt of SAR ${m(x.debt)} million against equity of SAR ${m(x.equity)} million. Funded debt-to-equity is ${(x.debt/x.equity).toFixed(2)}×. These ratios do not establish the quality of current assets or equity. Receivables may include disputed or related-party items, inventory may be slow moving, and equity may include balances that require adjustment under bank methodology.

The analyst should investigate the relationship between growth, margin, working-capital absorption and cash generation rather than regard revenue growth alone as favourable. Audit qualifications, going-concern emphasis, subsequent events and the quality of management accounts must be explicitly reviewed. No audit assurance or independent accounting validation is represented by the sample figures.`, 'S3'),

    section('Bank account conduct & cash movements',`
Bank conduct should be assessed across all material banking relationships and over a period that captures seasonality. The assessment should identify average and minimum balances, limit utilisation, payment returns, excesses, persistent negative positions, debt repayments and unusual end-period movements. The available demonstration bank schedule is not a substitute for this full coverage.

Operating customer receipts must be separated from loan disbursements, sponsor capital, inter-account transfers, refunds and non-recurring asset sales. The same transfer should not be counted as revenue when it moves between the borrower's accounts. Cash deposits, third-party receipts and related-party flows may require further explanation and corroboration.

The current case contains a draft banking review. It does not provide an independently verified conduct conclusion, complete reconciliation of turnover, or assurance about the authenticity of statements. The analyst should obtain statements through an approved route where possible, confirm arithmetic and period continuity, and reconcile classified transactions to the underlying totals. Material unexplained flows should remain visible as outstanding matters in the final proposal.`, 'S4, S5'),

    section('Working capital & concentration',`
The funding assessment should connect the receivables collection period, inventory holding period and supplier payment period to the proposed facility. Each component should be based on relevant eligible balances and appropriate denominators rather than a single aggregate ratio. Material related-party, overdue, disputed or ineligible items should be identified separately.

${x.customers}. The analyst should determine whether concentration is mitigated by contract strength, customer credit quality, payment performance or alternative demand. Mitigation is not established merely because counterparties are described as large or established. Contract enforceability, invoicing disputes and the ability to redirect collections need supporting evidence.

Seasonal requirements should be analysed monthly, including the peak borrowing period and the expected source of reduction. A permanent working-capital deficit should not be presented as a short seasonal gap without explanation. The proposed limit should be compared with observed utilisation, unutilised existing lines and the borrower's contribution. Final eligible assets, advance rates and monitoring triggers must follow the configured approved policy, which has not been supplied in full here.`, 'S3, S4, S6'),

    section('Existing debt, bureau & total exposure',`
The synthetic spread records funded debt of SAR ${m(x.debt)} million. This amount requires reconciliation with the detailed liability schedule, facility letters, banking repayments and authorised credit bureau information. The bank should also capture non-funded commitments, guarantees, leases, contingent liabilities and relevant related-party obligations.

No live bureau/SIMAH report or external default search has been retrieved for this demonstration. It would therefore be inappropriate to state that the borrower has a clean repayment record, no undisclosed debt or no adverse credit events. Those conclusions require a current authorised report and review of any differences or exceptions.

The credit reviewer should establish aggregate borrower and connected-group exposure after the proposed facility, distinguish limits from outstanding balances and consider utilisation assumptions. Refinancing, bullet maturities and commitments at other lenders should be reflected in the repayment assessment. Any inconsistency between declared obligations and independent evidence should be resolved before a positive recommendation is finalised.`, 'S3, S5, S6'),

    section('Repayment capacity & base case',`
The demonstration annual cash available for debt service is SAR ${m(x.cash)} million. Total annual debt service, including existing and proposed obligations, is SAR ${m(x.service)} million. Base cash-flow DSCR is therefore ${base.toFixed(2)}×. The numerator is a reviewed cash-flow input in the example and is deliberately distinguished from EBITDA of SAR ${m(x.ebitda)} million.

For live underwriting, the cash bridge should explain operating earnings, working-capital changes, tax, maintenance capital expenditure, distributions and other recurring requirements. Debt service must include principal, interest and other payments consistent with the bank's methodology. Both numerator and denominator must cover the same period, entity perimeter and currency.

Repayment should principally arise from sustainable operating cash generation. Sponsor injections, asset sales and refinancing should be assessed as separate contingent sources rather than silently included as recurring cash. ${quantitativeReferral?'The current quantitative profile warrants particular scrutiny and a documented assessment of resizing or restructuring before any policy exception is considered.':'The base calculation indicates an apparent buffer, but that buffer remains conditional on the reliability of forecasts and full identification of debt obligations.'} A positive lending decision cannot be inferred from DSCR alone.`, 'S3, S5, S6'),

    section('Downside scenarios & sensitivities',`
Applying a 20% reduction to cash available, with debt service unchanged, reduces DSCR from ${base.toFixed(2)}× to ${down.toFixed(2)}×. Combining that cash reduction with a 10% increase in annual debt-service burden produces DSCR of ${combined.toFixed(2)}×. These are illustrative analyst scenarios for the prototype, not published bank policy requirements or a calibrated stress model.

The scenario set should be tailored to the borrower. Relevant changes may include delayed customer collections, lower contract volumes, margin compression, cost increases, rate changes, currency mismatches or loss of a major counterparty. A revenue reduction should not automatically be translated one-for-one into cash loss: the effect depends on variable costs, fixed costs and working-capital behaviour.

The reviewer should identify the point at which repayment capacity becomes insufficient, the expected timing of any shortfall and practical mitigants. Mitigation may require a smaller facility, revised amortisation, additional borrower contribution, controlled collections or a credible liquidity reserve. A collateral proposal alone should not obscure inability to service the facility from the primary repayment source.`, 'S5, analyst scenario assumptions'),

    section('Industry, market & operational dependencies',`
The business is classified as ${x.sector.toLowerCase()}. Sector analysis should address the borrower's actual activities, contract structure, cost base and market exposures. No current external sector study or independently sourced market forecast has been included in the demonstration. Assertions about industry growth, competitive leadership or regulatory outlook are therefore intentionally left unconfirmed.

Operational review should consider key premises, equipment, permits, critical suppliers, customer access, logistics, insurance and management information. Business interruption and dependency on a single location or system should be assessed in proportion to the exposure. For any expansion request, implementation readiness and the delay between expenditure and cash generation need explicit consideration.

The relationship manager should document findings from interviews and site visits with dates, participants, observations and supporting evidence. Management representations should not be presented as direct observations. Material permit, insurance, service-continuity or capacity gaps should be translated into closure requirements or conditions, with a responsible owner and a clear point in the approval/disbursement process.`, 'S1, S6; external sector and field evidence outstanding'),

    section('Collateral, guarantees & recovery support',`
Proposed support is described as: ${x.security}. This is an applicant proposal and draft structuring description. Ownership, valuation, existing encumbrances, ranking, enforceability, insurance and perfection have not been independently verified in the example.

Security coverage should be calculated using eligible values and approved haircuts, without double counting the same asset across connected exposures. Receivables assignments require a practical assessment of eligible counterparties, disputes, set-off, dilution and control of proceeds. Asset security requires identification, condition and valuation by an approved route. Guarantees require separate review of legal validity and guarantor financial capacity.

Collateral is a secondary recovery source. The bank should assess realisation timing, costs and relevant legal limitations rather than assume book value equals cash recovery. Final documents and perfection steps must be reviewed by authorised specialists. The memorandum should state which requirements precede approval, which precede disbursement and which are ongoing covenants. No legal opinion, recovery estimate or approved LGD model is implied by this sample.`, 'S2, S6'),

    section('Policy compliance & exception assessment',`
The interface currently uses a labelled demonstration policy baseline. Its numerical values are not confirmed bank thresholds. The original SME eligibility rules from the photographed requirements remain subject to obtaining the approved source document. A saved or tested draft configuration must not be treated as an effective credit policy.

The base case DSCR is ${base.toFixed(2)}×, current ratio ${x.current.toFixed(2)}×, funded debt/equity ${(x.debt/x.equity).toFixed(2)}× and stated business vintage ${x.vintage} years. ${quantitativeReferral?'The example requires referral under one or more demonstration financial checks; the analyst should document the precise cause and proposed response.':'These values meet the initial illustrative quantitative checks; that result does not establish compliance with all actual eligibility, documentation or concentration requirements.'}

Any proposed exception should cite the exact applicable rule, explain its materiality, identify compensating factors and follow configured authority. Mandatory hard restrictions, unconfirmed policy wording and missing compliance clearance should not be converted into ordinary exceptions. Changes in case evidence or policy version require reassessment, and the final decision should retain the rule version used.`, 'S3, S5; demonstration policy configuration'),

    section('Compliance, fraud, conduct & data risks',`
The required specialist review includes ownership and identity due diligence, sanctions and relevant adverse-information screening, permitted business activity and suspicious or inconsistent information. No live screening result has been supplied. A document or AI summary should not be labelled as Compliance clearance without the authorised reviewer's recorded conclusion.

Fraud indicators may arise from statement manipulation, duplicate invoices, circular payments, unexplained turnover spikes or conflicts between financial, tax and banking information. An indicator is a matter for investigation rather than proof of fraud. Material unresolved concerns should be referred under the bank's procedures and should remain visible as workflow blockers.

Data risks include poor scans, mixed-language extraction errors, misread numerals, reporting-period confusion and incorrect monetary scale. The live application should preserve original source content, show confidence/evidence, and require human confirmation of material inputs. Privacy, retention, access and Azure processing-location requirements need to be configured and approved for real borrower data. None of these controls is established solely by the presence of an AI model or cloud hosting.`, 'S1–S6; specialist clearances outstanding'),

    section('Key risks, mitigants & residual concerns',`
1. Cash-flow reliability: validate the bridge from earnings to annual cash available and reconcile debt service. Mitigation is completion of source-based analysis, not reliance on a single ratio.

2. Concentration: ${x.customers}. Obtain contractual and ageing evidence, assess counterparty quality and identify realistic alternative collection sources.

3. Funding mismatch: confirm that facility tenor and repayment align with the operating or investment cycle. Resize or restructure if the funding gap is permanent or forecasts rely on uncertain refinancing.

4. Information and external-credit gaps: reconcile statements, liabilities, bureau findings and group exposure. Any undisclosed debt or material discrepancy requires a documented response.

5. Security execution: confirm ${x.security.toLowerCase()}. Do not attribute recovery benefit before eligible value and legal enforceability are established.

Residual concerns remain until the evidence is received, specialist conclusions are recorded and independent Credit challenges the complete proposal. A proposed mitigant should have an accountable owner and a verifiable completion criterion. The committee should be able to distinguish completed mitigation from a future commitment.`, 'S2–S6; outstanding action register'),

    section('Proposed terms, covenants & conditions',`
Proposed facility: ${x.facility}; requested limit ${money(x.amount)}; tenor ${x.tenor}; purpose ${x.purpose.toLowerCase()}. Pricing, repayment dates, fees, utilisation controls and any permitted availability period require an approved product and risk-pricing decision. No final pricing or credit offer is made in this memorandum.

Potential pre-decision requirements are confirmation of legal identity and borrowing powers, complete financial and banking reconciliation, current bureau/group-exposure review, validated cash-flow assumptions and required specialist clearances. Potential pre-disbursement conditions include executed agreements, verified borrower contribution where applicable, approved security documents and completion of required perfection steps.

Ongoing obligations may include periodic financial information, receivables ageing, covenant reporting, insurance renewal, material adverse-change notification and review of the facility at the agreed date. Quantitative covenant levels should come from the approved policy and negotiated facility structure. Conditions must be specific, assigned and separately tracked; conditional credit approval does not itself authorise funds release.`, 'S5, S6; proposed structuring assumptions'),

    section('Credit recommendation & approval route',`
Draft recommendation: ${quantitativeReferral?'REFER FOR RESIZING / MITIGATION AND, IF PERMITTED, FORMAL EXCEPTION REVIEW.':'PROCEED TO INDEPENDENT CREDIT REVIEW ONCE THE OUTSTANDING EVIDENCE AND CLEARANCES ARE COMPLETE.'}

The proposed ${money(x.amount)} exposure should be routed using the bank's approved delegated authority and aggregate connected exposure. The configuration shown in this preview contains only illustrative limits. It does not establish that a particular officer or committee has authority to approve the case.

The preparing officer should attest that material facts, calculations and assumptions are supported and that unresolved matters are clearly presented. An independent reviewer should challenge repayment capacity, funding need, policy interpretation and the adequacy of mitigants. The authorised approver should record the decision, rationale, conditions and any approved deviation against the exact assessment version.

No automatic approval, sanction-letter dispatch, security certification or disbursement is performed here. The current memo remains a draft until its evidence and narrative have been reviewed. Later material changes require a new assessment or controlled revision; they should not overwrite the record supporting an earlier decision.`, 'Complete assessment and configured delegation; human decision outstanding'),

    section('Evidence register & outstanding actions',`
S1 — Synthetic commercial registration and identity profile: legal name, Arabic name, demonstration registration and stated operating history. Independent registry confirmation remains required.

S2 — Synthetic ownership/constitutional schedule: sponsors, control and authority. Ultimate ownership, connected group and borrowing powers require corroboration.

S3 — Synthetic FY2023–2025 financial spread: revenue, EBITDA, liquidity, debt and equity. This is not an audited borrower submission.

S4 — Synthetic banking schedule: distinguish operating receipts, financing, sponsor injections and transfers. Full-period and all-bank reconciliation is outstanding.

S5 — Synthetic cash-flow and debt-service schedule: numerator, denominator and downside assumptions used in the repayment calculation. Forecast validation and liability completeness remain open.

S6 — Synthetic commercial, debt and security schedules: support financing purpose, contracts, funding need and proposed security. External bureau, valuation and legal enforceability are not confirmed.

Outstanding actions: obtain approved policy wording and delegation; complete source reconciliation; resolve discrepancies; validate group exposure and cash flows; record Compliance/Legal/Fraud conclusions; review security; independently challenge and approve the final memo. Each action requires a named owner and due date in the connected workflow.`, 'S1–S6; analyst assumptions explicitly identified')
  ];
}
