"""Preserve the approved HTML shell and append the authenticated API adapter."""
from pathlib import Path
import hashlib
import json
root=Path(__file__).resolve().parents[2]
approved=root/'01_Product_and_Design/approved-frontend.html'
html=approved.read_text(encoding='utf-8')
boot='''<style>html[data-vica-live="loading"] #vica-v2{visibility:hidden}</style>
<script>if(new URLSearchParams(location.search).get('connected')==='1'){document.documentElement.dataset.vicaLive='loading';const css=document.createElement('link');css.rel='stylesheet';css.href='/vica-live.css';document.head.appendChild(css);}</script>
'''
loader='''<script>if(new URLSearchParams(location.search).get('connected')==='1'){const live=document.createElement('script');live.src='/vica-live.js';live.onerror=()=>{document.documentElement.dataset.vicaLive='ready';document.getElementById('vica-v2').innerHTML='<p style="padding:30px">The connected application could not load. Refresh or contact the deployment administrator.</p>';};document.body.appendChild(live);}</script>
'''
html=html.replace('</head>',boot+'</head>',1).replace('</body>',loader+'</body>',1)
(root/'04_Frontend/public/vica-review.html').write_text(html,encoding='utf-8')
(root/'04_Frontend/public/approved-preview.html').write_bytes(approved.read_bytes())
print('Built connected ViCA page from approved shell. Reference SHA256:',hashlib.sha256(approved.read_bytes()).hexdigest())
