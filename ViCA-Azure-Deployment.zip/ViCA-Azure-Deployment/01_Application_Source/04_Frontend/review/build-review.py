"""Rebuild the browser review from its retained page and editable JS/CSS modules."""
from pathlib import Path

review = Path(__file__).resolve().parent
page = review.parent / 'public' / 'vica-review.html'
runtime = (review / 'vica-v2.js').read_text(encoding='utf-8')
runtime = runtime.replace('/* MEMO_FACTORY_START */\n  /* MEMO_FACTORY_END */',
                          (review / 'memo-factory.js').read_text(encoding='utf-8'))
runtime = runtime.replace('/* SECTION_CONFIGURATION */',
                          (review / 'section-configuration.js').read_text(encoding='utf-8'))
assert 'function memoFactory' in runtime and '/* SECTION_CONFIGURATION */' not in runtime
html = page.read_text(encoding='utf-8')
start = html.rindex('<script>') + len('<script>')
end = html.rindex('</script>')
html = html[:start] + runtime + html[end:]
css_start = '/* SECTION_CONFIG_CSS_START */'
css_end = '/* SECTION_CONFIG_CSS_END */'
start = html.index(css_start) + len(css_start)
end = html.index(css_end)
html = html[:start] + '\n' + (review / 'section-configuration.css').read_text(encoding='utf-8') + '\n' + html[end:]
page.write_text(html, encoding='utf-8')
(review / 'vica-runtime.generated.js').write_text(runtime, encoding='utf-8')
print('Rebuilt', page)
