'use client';
import {useEffect,useRef} from 'react';
import {entraToken} from '../lib/auth';

type Message={type:string,id?:string,path?:string,method?:string,body?:unknown,file?:File,
  token?:string,role?:string,subject?:string};

export default function Page(){
  const frame=useRef<HTMLIFrameElement>(null);
  const credentials=useRef({token:'',role:'Analyst',subject:'demo-analyst'});
  const local=process.env.NEXT_PUBLIC_AUTH_MODE==='local';
  useEffect(()=>{
    let disposed=false;
    const send=(message:unknown)=>{if(!disposed)frame.current?.contentWindow?.postMessage(message,window.location.origin);};
    async function api(message:Message){
      if(!message.path||!/^\/(me|applications|policy|configuration)(?:[/?]|$)/.test(message.path)||message.path.includes('..')||message.path.includes('://'))throw new Error('Unsupported API path');
      const headers=new Headers();
      const token=local?credentials.current.token:await entraToken();
      if(!token)throw new Error('Sign in to continue');
      headers.set('Authorization','Bearer '+token);
      if(local){headers.set('X-Dev-Role',credentials.current.role);headers.set('X-Dev-User',credentials.current.subject);}
      let body:BodyInit|undefined;
      if(message.file){const form=new FormData();form.append('file',message.file);body=form;}
      else if(message.body!==undefined){headers.set('Content-Type','application/json');body=JSON.stringify(message.body);}
      if(message.path==='/applications'&&message.method==='POST')headers.set('Idempotency-Key',crypto.randomUUID());
      const response=await fetch('/api/v1'+message.path,{method:message.method||'GET',headers,body,cache:'no-store',signal:AbortSignal.timeout(240000)});
      if(!response.ok){const error=await response.json().catch(()=>({detail:response.statusText}));throw new Error(typeof error.detail==='string'?error.detail:JSON.stringify(error.detail));}
      return response.headers.get('Content-Type')?.includes('application/json')?response.json():response.blob();
    }
    async function session(){
      try{const me=await api({type:'api',path:'/me'});send({type:'vica:session',me,local});}
      catch(error){send({type:'vica:session',local,error:error instanceof Error?error.message:'Sign in required'});}
    }
    async function receive(event:MessageEvent<Message>){
      if(event.origin!==window.location.origin||event.source!==frame.current?.contentWindow)return;
      const message=event.data;
      if(message?.type==='vica:ready'){await session();return;}
      if(message?.type==='vica:login'){
        try{if(local){credentials.current={token:message.token||'',role:message.role||'Analyst',subject:message.subject||'demo-analyst'};}else await entraToken(true);await session();}
        catch(error){send({type:'vica:session',local,error:error instanceof Error?error.message:'Sign-in failed'});}return;
      }
      if(message?.type!=='vica:request'||typeof message.id!=='string')return;
      try{const result=await api(message);send({type:'vica:response',id:message.id,result});}
      catch(error){send({type:'vica:response',id:message.id,error:error instanceof Error?error.message:'Request failed'});}
    }
    window.addEventListener('message',receive);
    return()=>{disposed=true;window.removeEventListener('message',receive);};
  },[local]);
  return <iframe ref={frame} src="/vica-review.html?connected=1" title="ViCA Virtual Credit Analyst" style={{position:'fixed',inset:0,width:'100%',height:'100%',border:0,background:'#f6f8fb'}}/>;
}
