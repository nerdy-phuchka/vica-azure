import './styles.css';
export const metadata={title:'ViCA | Virtual Credit Analyst',description:'SME underwriting workspace'};
export default function Layout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}
