import LegacyWorkspace from '../../components/LegacyWorkspace';
export default LegacyWorkspace;
