export const metadata={title:'ViCA | Revised front-end review'};
export default function DesignReview(){
  return <iframe title="ViCA revised front-end — synthetic demonstration" src="/vica-review.html" style={{display:'block',width:'100%',height:'100dvh',border:0}}/>;
}
