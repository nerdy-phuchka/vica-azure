export function GET(){return Response.json({status:'ok',service:'vica-web',version:'0.2.0'});}
