import {NextRequest} from 'next/server';
export const runtime='nodejs';
export const dynamic='force-dynamic';

async function proxy(request:NextRequest,{params}:{params:Promise<{path:string[]}>}) {
  const {path}=await params;
  // Fixed origin and allow-listed prefix prevent arbitrary URL forwarding.
  if(path[0]!=='v1' || path.some(p=>p==='..' || p.includes('://'))) return new Response('Not found',{status:404});
  const url=new URL('/api/'+path.map(encodeURIComponent).join('/'),process.env.API_INTERNAL_URL||'http://127.0.0.1:8000');
  url.search=request.nextUrl.search;
  const headers=new Headers();
  for(const key of ['authorization','content-type','idempotency-key']) {
    const value=request.headers.get(key); if(value) headers.set(key,value);
  }
  if(process.env.NEXT_PUBLIC_AUTH_MODE==='local') {
    for(const key of ['x-dev-user','x-dev-role']) {const v=request.headers.get(key); if(v)headers.set(key,v);}
    if(process.env.DEV_PROXY_SECRET)headers.set('X-VCA-Local-Proxy',process.env.DEV_PROXY_SECRET);
  }
  const length=Number(request.headers.get('content-length')||0);
  if(length>51*1024*1024)return new Response('Upload limit exceeded',{status:413});
  try {
    let body:Uint8Array|undefined;
    if(!['GET','HEAD'].includes(request.method)) {
      const chunks:Uint8Array[]=[];let total=0;
      const reader=request.body?.getReader();
      if(reader)while(true){const chunk=await reader.read();if(chunk.done)break;total+=chunk.value.length;
        if(total>51*1024*1024){await reader.cancel();return new Response('Upload limit exceeded',{status:413});}
        chunks.push(chunk.value);
      }
      body=new Uint8Array(total);let offset=0;for(const chunk of chunks){body.set(chunk,offset);offset+=chunk.length;}
    }
    const upstream=await fetch(url,{method:request.method,headers,
      body:body as BodyInit|undefined,
      redirect:'manual',signal:AbortSignal.timeout(240000)});
    const responseHeaders=new Headers({'Cache-Control':'no-store'});
    for(const key of ['content-type','content-disposition','x-request-id']) {
      const value=upstream.headers.get(key);if(value)responseHeaders.set(key,value);
    }
    return new Response(upstream.body,{status:upstream.status,headers:responseHeaders});
  } catch {return Response.json({detail:'Backend unavailable. Check API deployment and connectivity.'},{status:502});}
}
export {proxy as GET,proxy as POST};
